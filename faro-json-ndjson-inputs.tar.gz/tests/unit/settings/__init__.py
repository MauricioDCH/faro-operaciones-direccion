"""Unit tests for settings."""
