"""Synthetic PDF fixture builders."""
