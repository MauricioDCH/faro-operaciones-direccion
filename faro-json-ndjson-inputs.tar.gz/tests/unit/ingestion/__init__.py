"""Excel ingestion unit tests."""
